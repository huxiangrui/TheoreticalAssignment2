import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
public class ATMGUI extends JFrame{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ATMGUI(){
    	this.setTitle("ATM");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(100, 100, 600, 500);
        JPanel contentPane=new JPanel();
        JFrame f=new JFrame();
        Container con=f.getContentPane();
        contentPane.setBorder(new EmptyBorder(5,5,5,5));// �������ı߿� �������ϡ����¡��� �ľ���
        this.setContentPane(contentPane);
        contentPane.setLayout(new GridLayout(3,3,5,5));
        String ta=("Withdraw menu"+"/n"+"1 -  $20    4 - $100"+"2 - $40    5 - $200"+"/n"
        +"3 - $60    6 - 400"+"/n"+"Choose a withdraw amount");
        JTextArea tishi=new JTextArea(400,200);
        tishi.append(ta);
        JLabel l1=new JLabel("Take cash here",400);
        JLabel l2=new JLabel("Insert deposit envelope here",400);
        JButton zero=new JButton("0");
        JButton one=new JButton("1");
        JButton two=new JButton("2");
        JButton three=new JButton("3");
        JButton four=new JButton("4");
        JButton five=new JButton("5");
        JButton six=new JButton("6");
        JButton seven=new JButton("7");
        JButton eight=new JButton("8");
        JButton nine=new JButton("9");
        JButton enter=new JButton("Enter");
        contentPane.add(zero);
        contentPane.add(one);
        contentPane.add(two);
        contentPane.add(three);
        contentPane.add(four);
        contentPane.add(five);
        contentPane.add(six);
        contentPane.add(seven);
        contentPane.add(eight);
        contentPane.add(nine);
        contentPane.add(enter);
        this.setVisible(true);

    }
	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		ATMGUI example=new ATMGUI();
	}
}                                
